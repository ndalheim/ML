package interfaces;

/**
 * Created by ken on 28.05.2018.
 */
public interface DeepCloneable<T> {

    public T deepClone();

}
