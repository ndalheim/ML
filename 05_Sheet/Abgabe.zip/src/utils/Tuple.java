package utils;

/**
 * Created by ken on 28.05.2018.
 */
public class Tuple<T> {

    T x;
    T y;
    T z;

    public Tuple(T x, T y, T z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
