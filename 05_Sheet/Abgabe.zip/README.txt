
Wie in der Aufgabenstellung angegeben, kann der Algorithmus einfach gestartet werden.
Da nur der naive Bayes algorithmus umgesetzt wurde, ist kein Papier zur Erkl�rung von Verbesserungen angegeben.

java -jar <Path to test data> <Predictions filename>

Beispiel:
java -jar .\Bayes.jar C:\Users\ken\uni\08_UNI_SS_18\ML\data\train3500.txt predictions.txt

