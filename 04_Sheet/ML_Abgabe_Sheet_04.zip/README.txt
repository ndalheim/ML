Machine Learning
Blatt 4
Nadine Dalheimer, Ken Moller, Alexander Kindl

Das Programm kann f�r die verschiedenen Aufgaben in 3 Modi ausgef�hrt werden. 
Dieser wird mit dem ersten �bergebenen Arugument bestimmt. ( folds, cv, weka )

Um die Folds zu generieren :
----------------------------
java -jar Tasks.jar <Modus> <Source arff file> <Class index> <Output dir> <num folds>

Beispiel : 
java -jar Tasks.jar folds C:\Users\nadine\uni\08_UNI_SS_18\ML\data\weather.nominal.arff 4 C:\Users\nadine\uni\08_UNI_SS_18\ML\04_Sheet\out 10


Um die cross validation auszuf�hren:
------------------------------------
java -jar Tasks.jar <Modus> <Source arff file> <classAttribute> <max tree depth> <num folds>

Beispiel:
java -jar Tasks.jar cv C:\Users\nadine\uni\08_UNI_SS_18\ML\data\car.arff 6 6 10


Um den weka part auszuf�hren:
-----------------------------
java -jar Tasks.jar <Modus> <Directory of folds> <relation name (file name)> <Source arff file> <Num folds> <Class index>

Beispiel:
java -jar Tasks.jar weka C:\Users\nadine\uni\08_UNI_SS_18\ML\04_Sheet\out\car car C:\Users\nadine\uni\08_UNI_SS_18\ML\data\car.arff 10 6

