Machine Learning
Sheet 01

Date: 25.04.2018
Version: 0.1
Author: Ken Moller, Nadine Dalheimer, Alexander Kindl

Description:

Start the main and enter the path of your arff file you want to compute.
After that select the number of the classAttribute in your arff file you want to select as classAttribute (e.g. you have 5 attributes in total and the last one (play) you want to select so you enter the number: 4). Finally select the attribute number of the attribute you want to compute the information gain (e.g. the humidity number: 2)


EXAMPLE:

Our results for classAttribute: play, attribute: humidity of the weather.nominal.arff file:

information gain: 0.15183550136234147